package com.ftn.model;

public class StateModel {
	
	private String text;
	
	
	public StateModel() {
		
	}
	
	public StateModel(String text) {
		this.text = text;
	}
	
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}
	
}
