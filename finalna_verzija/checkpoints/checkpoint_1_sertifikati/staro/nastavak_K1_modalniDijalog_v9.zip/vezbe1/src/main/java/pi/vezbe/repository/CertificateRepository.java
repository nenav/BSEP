package pi.vezbe.repository;

import org.springframework.data.repository.CrudRepository;

import pi.vezbe.model.CertificateModel;

public interface CertificateRepository extends CrudRepository<CertificateModel, Integer> {

	CertificateModel findBySerialNum(String serialNum);
	
}