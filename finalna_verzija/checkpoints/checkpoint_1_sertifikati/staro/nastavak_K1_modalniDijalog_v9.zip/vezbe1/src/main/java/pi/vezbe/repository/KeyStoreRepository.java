package pi.vezbe.repository;

import org.springframework.data.repository.CrudRepository;

import pi.vezbe.model.KeyStoreModel;

public interface KeyStoreRepository extends CrudRepository<KeyStoreModel, Integer> {

	KeyStoreModel findByKsFileName(String ksFileName);
}
