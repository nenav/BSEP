insert into backend.user values (1111111111, 'admin@email.com', 'admin', 'admin', 'admin@Admin111', 0, 2, 'admin');
insert into backend.user values (2222222222, 'manager@email.com', 'manager', 'manager', 'manager@Manager222', 0, 1, 'manager');
insert into backend.user values (3333333333, 'petar@email.com', 'Petar', 'Milenkovic', 'password@Pera333', 0, 0, 'pera93');
insert into backend.user values (4444444444, 'zoki@email.com', 'Zoran', 'Markovic', 'password@Zoki444', 0, 0, 'zoki94');
insert into backend.user values (5555555555, 'aleks@email.com', 'Aleksandra', 'Jovanovic', 'password@Aleks555', 0, 0, 'aleks95');

insert into backend.permission values (1, 'Registration', 0, 0, 1);
insert into backend.permission values (2, 'Login', 1, 1, 1);
insert into backend.permission values (3, 'Logout', 1, 1, 1);
insert into backend.permission values (4, 'Change Password', 1, 1, 1);
insert into backend.permission values (5, 'Reset Password', 0, 0, 1);
insert into backend.permission values (6, 'Approve Account Activation', 1, 1, 0);
insert into backend.permission values (7, 'Decline Account Activation', 1, 1, 0);
insert into backend.permission values (8, 'Search', 1, 1, 1);
insert into backend.permission values (9, 'Reserve Accomodation', 0, 0, 1);
insert into backend.permission values (10, 'Cancel Reservation', 0, 1, 1);
insert into backend.permission values (11, 'Send Message', 0, 1, 1);
insert into backend.permission values (12, 'Rate Accomodation', 0, 0, 1);
insert into backend.permission values (13, 'Post Comment', 0, 0, 1);
insert into backend.permission values (14, 'Manage Reservation', 0, 1, 0);
insert into backend.permission values (15, 'Offer Accomodation', 0, 1, 0);
insert into backend.permission values (16, 'Manage User', 1, 0, 0);
insert into backend.permission values (17, 'Publish Comments', 1, 0, 0);
insert into backend.permission values (18, 'Maintain Data (for managers)', 1, 0, 0);


