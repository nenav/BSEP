package com.xws.backend.model;

public enum UserStatus {
	ACTIVATED, PENDING, DECLINED
}
