package com.xws.backend.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "permission")
public class Permission {
	
	@Id
	@GeneratedValue
	private Long id;
	
	@Column(nullable = false)
	private String availablePrivilege;
	
	@Column(nullable = false)
	private Boolean hasUserAuthority;
	
	@Column(nullable = false)
	private Boolean hasManagerAuthority;
	
	@Column(nullable = false)
	private Boolean hasAdminAuthority;
	
	
	public Permission() {
		
	}
	
	public Permission(Long id, String availablePrivilege, Boolean hasUserAuthority, Boolean hasManagerAuthority,
			Boolean hasAdminAuthority) {
		super();
		this.id = id;
		this.availablePrivilege = availablePrivilege;
		this.hasUserAuthority = hasUserAuthority;
		this.hasManagerAuthority = hasManagerAuthority;
		this.hasAdminAuthority = hasAdminAuthority;
	}


	public String getAvailablePrivilege() {
		return availablePrivilege;
	}

	public void setAvailablePrivilege(String availablePrivilege) {
		this.availablePrivilege = availablePrivilege;
	}

	public Boolean getHasUserAuthority() {
		return hasUserAuthority;
	}

	public void setHasUserAuthority(Boolean hasUserAuthority) {
		this.hasUserAuthority = hasUserAuthority;
	}

	public Boolean getHasManagerAuthority() {
		return hasManagerAuthority;
	}

	public void setHasManagerAuthority(Boolean hasManagerAuthority) {
		this.hasManagerAuthority = hasManagerAuthority;
	}

	public Boolean getHasAdminAuthority() {
		return hasAdminAuthority;
	}

	public void setHasAdminAuthority(Boolean hasAdminAuthority) {
		this.hasAdminAuthority = hasAdminAuthority;
	}
	
	
}
