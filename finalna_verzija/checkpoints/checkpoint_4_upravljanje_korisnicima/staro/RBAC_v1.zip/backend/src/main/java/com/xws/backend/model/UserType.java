package com.xws.backend.model;

public enum UserType {

	USER, MANAGER, ADMIN 
}
