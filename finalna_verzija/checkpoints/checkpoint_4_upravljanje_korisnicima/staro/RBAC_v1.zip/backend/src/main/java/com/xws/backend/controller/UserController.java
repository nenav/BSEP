package com.xws.backend.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.xws.backend.model.User;
import com.xws.backend.model.UserStatus;
import com.xws.backend.service.UserService;

@SuppressWarnings("rawtypes")
@RestController
@RequestMapping("/user")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	
	private UserService userService;
	
	public UserController(UserService userService) {
		this.userService = userService;
	}
	
	
	@PostMapping("/login")
    public ResponseEntity login(@RequestBody User user, HttpServletRequest request) {
		logger.debug("REST request to login into system!");
		User u = this.userService.findByUsername(user);
		if (u != null && u.getUserStatus() == UserStatus.ACTIVATED) {
			request.getSession().setAttribute("user", u);
			return new ResponseEntity<>(HttpStatus.OK);
		} else if (u != null && u.getUserStatus() == UserStatus.PENDING){
			return new ResponseEntity<>(HttpStatus.FORBIDDEN);
		}else {
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping("/logout")
	public ResponseEntity logout(HttpServletRequest request) {
		logger.debug("REST request to logout from the system!");
		request.getSession().removeAttribute("user");
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping("/account")
	public ResponseEntity<User> account(HttpServletRequest request) {
		logger.debug("REST request to get account data!");
		User user = (User) request.getSession().getAttribute("user");
		if (user != null) {
			return new ResponseEntity<>(user, HttpStatus.OK);
		} else {
			return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
		}
	}
	
	@PostMapping("/register")
	public ResponseEntity register(@RequestBody User user, HttpServletRequest request) {
		logger.debug("REST request to get register user!");
		boolean b = this.userService.register(user);
		if (b) {
			return new ResponseEntity<>(HttpStatus.CREATED);
		}
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
	}
	
	@GetMapping("/not-activated")
	public ResponseEntity<List<User>> getNotActivated() {
		logger.debug("REST request to get not activated users");
		return new ResponseEntity<>(this.userService.getNotAcctivated(), HttpStatus.OK);
	}
	
	@PostMapping("/approve")
	public ResponseEntity approve(@RequestBody String id) {
		logger.debug("REST request to approve registration!");
		boolean b = this.userService.setStatus(id.substring(0, id.length()-1), UserStatus.ACTIVATED);
		if (b) return new ResponseEntity<>(HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/decline")
	public ResponseEntity decline(@RequestBody String id) {
		logger.debug("REST request to decline registration!");
		boolean b = this.userService.setStatus(id.substring(0, id.length()-1), UserStatus.DECLINED);
		if (b) return new ResponseEntity<>(HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/activation-email")
	public ResponseEntity emailActivation(@RequestBody String username) {
		logger.debug("REST request to reset password!");
		System.out.println(username);
		boolean b = this.userService.activationEmail(username.substring(0, username.length()-1));
		if (b) return new ResponseEntity<>(HttpStatus.OK);
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping("/reset-password")
	public ResponseEntity resetPassword(@RequestBody User user) {
		if (this.userService.resetPassword(user)) return new ResponseEntity<>(HttpStatus.OK);
		
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}
	
}
