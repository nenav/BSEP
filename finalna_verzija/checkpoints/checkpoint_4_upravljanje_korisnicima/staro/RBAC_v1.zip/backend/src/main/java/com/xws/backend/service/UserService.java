package com.xws.backend.service;

import java.util.List;

import com.xws.backend.model.User;
import com.xws.backend.model.UserStatus;

public interface UserService {

	public User findByUsername(User user);
	public boolean register(User user);
	public List<User> getNotAcctivated();
	public boolean setStatus(String id, UserStatus userStatus);
	public boolean activationEmail(String username);
	public boolean resetPassword(User user);
}
