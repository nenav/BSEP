package com.xws.backend.service;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.xws.backend.model.User;
import com.xws.backend.model.UserStatus;
import com.xws.backend.model.UserType;
import com.xws.backend.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService{

	private UserRepository userRepository;
	
	@Autowired
	public JavaMailSender emailSender;
	
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	@Override
	public User findByUsername(User user) {
		User u = this.userRepository.findByUsername(user.getUsername());
		if (u == null) return null;
		
		if (u.getPassword().equals(user.getPassword())) {
			return u;
		} else {
			return null;
		}
	}

	@Override
	public boolean register(User user) {
		user.setUserType(UserType.USER);
		user.setUserStatus(UserStatus.PENDING);
		
		String file ="passwordPatterns.txt";
		List<String> patterns = new ArrayList<String>();
	    try{
	        InputStream ips=new FileInputStream(file); 
	        InputStreamReader ipsr=new InputStreamReader(ips);
	        BufferedReader br=new BufferedReader(ipsr);
	        String line;
	        while ((line = br.readLine()) != null){
	        	patterns.add(line);
	        }
	        br.close();
	    }       
	    catch (Exception e){
	        System.out.println(e.toString());
	    } 
	    
	    for(int i = 0; i < patterns.size(); i++) {
	    	if(user.getPassword().equals(patterns.get(i))) {
	    		System.out.println("\n\n\n\t\t\tYou can not select the password that is in the list of most frequently used passwords (1)!");
	    		return false;
	    	}
	    }
		
		User u = this.userRepository.save(user);
		if (u != null) {
			return true;
		}
		return false;
	}

	@Override
	public List<User> getNotAcctivated() {
		return this.userRepository.findByUserStatusAndUserType(UserStatus.PENDING, UserType.USER);
	}

	@Override
	public boolean setStatus(String id, UserStatus userStatus) {
		Optional<User> u = this.userRepository.findById(Long.parseLong(id));
		if (u.isPresent()) {
			User user = u.get();
			user.setUserStatus(userStatus);
			this.userRepository.save(user);
			return true;
		}
		return false;
	}

	@Override
	public boolean activationEmail(String username) {
		User u = this.userRepository.findByUsername(username);
		System.out.println("USER " + u);
		if (u == null) return false;		
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setTo(u.getEmail());
		message.setSubject("Change your password");
		message.setText("To change your password, please follow the link:\n http://localhost:8080/resetpassword.html?u=" + u.getUsername());
		emailSender.send(message);
		return true;
	}

	@Override
	public boolean resetPassword(User user) {
		User u = this.userRepository.findByUsername(user.getUsername());
		if (u == null) return false;
		u.setPassword(user.getPassword());
		
		String file ="passwordPatterns.txt";
		List<String> patterns = new ArrayList<String>();
	    try{
	        InputStream ips=new FileInputStream(file); 
	        InputStreamReader ipsr=new InputStreamReader(ips);
	        BufferedReader br=new BufferedReader(ipsr);
	        String line;
	        while ((line = br.readLine()) != null){
	        	patterns.add(line);
	        }
	        br.close();
	    }       
	    catch (Exception e){
	        System.out.println(e.toString());
	    } 
	    
	    for(int i = 0; i < patterns.size(); i++) {
	    	if(user.getPassword().equals(patterns.get(i))) {
	    		System.out.println("\n\n\n\t\t\tYou can not select the password that is in the list of most frequently used passwords (2)!");
	    		return false;
	    	}
	    }
		
		this.userRepository.save(u);
		return true;
	}

}
