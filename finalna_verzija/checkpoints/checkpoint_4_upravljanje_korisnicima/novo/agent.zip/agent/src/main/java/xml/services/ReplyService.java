package xml.services;

import xml.web_services.Reply;

public interface ReplyService {

	Reply save(Reply reply);
	
}
