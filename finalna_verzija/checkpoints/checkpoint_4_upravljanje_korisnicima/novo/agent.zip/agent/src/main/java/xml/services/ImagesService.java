package xml.services;

import xml.web_services.Images;

public interface ImagesService {

	Images save(Images im);
	
}
