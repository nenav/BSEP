package xml.model;

public enum UserStatus {
	ACTIVATED, PENDING, DECLINED
}
