package xml.model;

public class MessageHelper {

	private Long accomodationId;
	private String content;
	
	public Long getAccomodationId() {
		return accomodationId;
	}
	
	public void setAccomodationId(Long accomodationId) {
		this.accomodationId = accomodationId;
	}
	
	public String getContent() {
		return content;
	}
	
	public void setContent(String content) {
		this.content = content;
	}
	
}
