package xml.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import xml.web_services.Adress;

public interface AdressRepository extends JpaRepository<Adress, Long>{

}
