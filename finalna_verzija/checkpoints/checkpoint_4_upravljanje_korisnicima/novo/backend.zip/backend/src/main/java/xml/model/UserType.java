package xml.model;

public enum UserType {
	USER, MANAGER, ADMIN 
}
